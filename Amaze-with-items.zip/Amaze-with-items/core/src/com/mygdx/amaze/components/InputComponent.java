package com.mygdx.amaze.components;

/**
 * Created by Randolph on 13/3/2016.
 */
public abstract class InputComponent {
    public abstract void update(float delta);
}
