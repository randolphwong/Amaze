package com.mygdx.amaze.components;

/**
 * Created by Dhanya on 24/03/2016.
 */
public class ItemPhysicsComponent {
}
